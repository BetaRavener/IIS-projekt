<?php
$db_address = 'localhost';
$db_login = 'xsevci50';
$db_password = '9amcicim';
$db_database = 'xsevci50';
$web_home = 'http://www.stud.fit.vutbr.cz/~xsevci50/IIS/';
?>