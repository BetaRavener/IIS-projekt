<?php

function place_session_cart_into_db($db , $userId)
{
    
}

function isOrderNotProcessed($orderState)
{
    return $orderState === 'přijatá';
}

?>