<?php
    header("Content-Type: text/html; charset=UTF-8");
    $mainInit = true;
    require_once 'config.php';
    require_once 'db.php';
    require_once 'loginDetection.php';
?>